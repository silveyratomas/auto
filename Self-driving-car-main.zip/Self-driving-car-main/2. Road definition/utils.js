function lerp(A,B,t){
    return A+(B-A)*t;
}